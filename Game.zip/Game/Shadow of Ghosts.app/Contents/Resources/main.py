from MainMenu import *

GameWindow = MenuScreen()
GameWindow.mainloop()
