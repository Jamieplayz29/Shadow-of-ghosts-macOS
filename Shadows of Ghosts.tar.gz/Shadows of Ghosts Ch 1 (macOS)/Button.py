
from tkinter import *


class ButtonFrame(Frame):

    def __init__(self, container, width, height, message, size):
        Frame.__init__(self, container, bg = 'black', width = width, height = height)
        self.Button = ButtonEffect(self, message, size)

class ButtonEffect(Label):

    def __init__(self, container, message, size):
        Label.__init__(self, container, text = message, bg = 'black', fg = 'white', font = ('MS Sans Serif', size))
        self.size = size
        self.bind('<Enter>', self.Over)
        self.bind('<Leave>', self.Off)

    def Over(self, event):
        self.config(font = ('MS Sans Serif', self.size, 'bold'))

    def Off(self, event):
        self.config(font = ('MS Sans Serif', self.size))