
from Button import *
from ImportDialogue import *
from tkinter import *
import random

class Chapter1(Toplevel):
    
    def __init__(self, window):
        Toplevel.__init__(self, window)

        self.window = window
        self.title('The Dark Room')
        self.geometry('1280x720')
        self.resizable(width = False, height = False)
        self.bind('<Return>', lambda event: self.Transition(event, self.currentFrame))
        self.bind('<Left>',lambda event: self.PreviousDialogue(event, self.currentFrame, self.currentDialogue))

        self.container = Frame(self, width = 1280, height = 720, bg = 'black')
        self.container.pack_propagate(False)
        self.container.pack()
        self.container.bind('<Button-1>', lambda event: self.Transition(event, self.currentFrame))
        self.container.bind('<Button-3>',lambda event: self.PreviousDialogue(event, self.currentFrame, self.currentDialogue))
        self.frames = {}
        self.currentFrame = None
        self.currentDialogue = None
        self.decision = False
        self.fightResult = None
        self.inFight = False
        self.inCombat = False
        self.playerTurn = False
        self.buttonPressed = False
        self.SMRoute = False

        self.dialogueLine = 0
        self.dialogueCE = []
        self.dialogueGA = []
        self.dialogueSM = []
        self.dialogueMP = []
        self.dialogueFR = []

        frameH = Header(self.container)
        self.frames[Header] = frameH
        frameF = Footer(self.container)
        self.frames[Footer] = frameF
        frameCT = ChapterTitle(self.container)
        self.frames[ChapterTitle] = frameCT
        frameCE = ChapterExposition(self.container)
        self.frames[ChapterExposition] = frameCE
        frameGA = GetAttention(self.container)
        self.frames[GetAttention] = frameGA
        frameSM = StayMotionless(self.container)
        self.frames[StayMotionless] = frameSM
        frameMP = MeetPerson(self.container)
        self.frames[MeetPerson] = frameMP
        frameFR = FightResult(self.container)
        self.frames[FightResult] = frameFR
        frameTBC = ToBeContinued(self.container)
        self.frames[ToBeContinued] = frameTBC

        self.ChapterStartUp()

    def ChapterStartUp(self):
        self.frames[Header].pack(side = 'top')
        self.frames[Footer].pack(side = 'bottom')

        self.frames[Header].backDropImage = PhotoImage(file = 'VinBack1Top.png')
        self.frames[Header].backDrop = Label(self.frames[Header], image = self.frames[Header].backDropImage)
        self.frames[Header].backDrop.pack(side = 'top')
        self.frames[Footer].backDropImage = PhotoImage(file = 'VinBack1Bottom.png')
        self.frames[Footer].backDrop = Label(self.frames[Footer], image = self.frames[Footer].backDropImage)
        self.frames[Footer].backDrop.pack(side = 'bottom')
        self.frames[Footer].battleImage = PhotoImage(file = 'VinBack2Cut.png')
        self.frames[Footer].battle = Label(self.frames[Footer], image = self.frames[Footer].battleImage, bg = 'black')

        self.frames[ChapterTitle].pack(side = 'top')
        self.frames[ChapterTitle].bind('<Button-1>', lambda event: self.Transition(event, self.currentFrame))
        self.frames[ChapterTitle].title.bind('<Button-1>', lambda event: self.Transition(event, self.currentFrame))
        self.currentFrame = self.frames[ChapterTitle]
        LoadDialogue('DialogueCE.txt', self.dialogueCE)
        LoadDialogue('DialogueGA.txt', self.dialogueGA)
        LoadDialogue('DialogueSM.txt', self.dialogueSM)
        LoadDialogue('DialogueMP.txt', self.dialogueMP)
        LoadDialogue('DialogueFR.txt', self.dialogueFR)


    def Transition(self, event, frame):
        if frame == self.frames[ChapterTitle]:
            self.NewFrame(None,self.currentFrame, self.frames[ChapterExposition], self.dialogueCE)

        elif frame == self.frames[ChapterExposition]:
            if self.dialogueLine == 8:
                self.dialogueLine = 0
                self.decision = True
                Decision1 = ButtonFrame(frame, 300, 100,'Stay Motionless', 24)
                Decision1.pack_propagate(False)
                Decision1.Button.bind('<Button-1>', lambda event: [self.NewFrame(event,frame,self.frames[StayMotionless], self.dialogueSM), self.SMRTrue()])
                Decision1.pack(side = 'left', padx = 100)
                Decision1.Button.pack()
                Decision2 = ButtonFrame(frame, 300, 100,'Get Attention',24)
                Decision2.pack_propagate(False)
                Decision2.Button.bind('<Button-1>', lambda event: self.NewFrame(event,frame,self.frames[GetAttention], self.dialogueGA))
                Decision2.pack(side = 'right', padx = 100)
                Decision2.Button.pack()
            elif self.decision == False:
                self.NextLine(frame, self.currentDialogue)

        elif frame == self.frames[GetAttention]:
            if self.dialogueLine == 9:
                self.dialogueLine = 0
                enemies = ['BigLad','BigLad']
                player = ['Player']
                framePF = PhysicalFight(self.container, False, player, enemies)
                self.frames[PhysicalFight] = framePF
                self.frames[Header].backDrop.pack_forget()
                self.frames[Footer].backDrop.pack_forget()
                self.frames[Footer].battle.pack()
                self.NewFrame(None,frame, self.frames[PhysicalFight], None)

                self.currentFrame.player[0] = Player(4)
                for i in range(0, len(self.currentFrame.enemies)):
                    self.currentFrame.enemies[i] = Enemy('Guard '+str(i+1),2, 10, 60, 75, 0, 90, 50, 30)
            elif self.decision == False:
                self.NextLine(frame, self.currentDialogue)

        elif frame == self.frames[StayMotionless]:
            if self.dialogueLine == 19:
                self.dialogueLine = 0
                self.decision = True
                enemies = ['BigLad','BigLad']
                player = ['Player']
                framePF = PhysicalFight(self.container, True, player, enemies)
                self.frames[PhysicalFight] = framePF
                self.frames[PhysicalFight].player[0] = Player(4)
                for i in range(0, len(self.frames[PhysicalFight].enemies)):
                    self.frames[PhysicalFight].enemies[i] = Enemy('Guard '+str(i+1),2, 10, 60, 75, 0, 90, 50, 30)

                Decision1 = ButtonFrame(frame, 300, 100,'Meet Person', 24)
                Decision1.pack_propagate(False)
                Decision1.Button.bind('<Button-1>', lambda event: self.NewFrame(event,frame,self.frames[MeetPerson], self.dialogueMP))
                Decision1.pack(side = 'left', padx = 100)
                Decision1.Button.pack()
                Decision2 = ButtonFrame(frame, 300, 100,'Surprise Attack', 24)
                Decision2.pack_propagate(False)
                Decision2.Button.bind('<Button-1>', lambda event: [self.NewFrame(event,frame,self.frames[PhysicalFight], None), self.frames[Header].backDrop.pack_forget(), self.frames[Footer].backDrop.pack_forget(), self.frames[Footer].battle.pack()])
                Decision2.pack(side = 'right', padx = 100)
                Decision2.Button.pack()
            elif self.decision == False:
                self.NextLine(frame, self.currentDialogue)
        elif frame == self.frames[MeetPerson]:
            if self.dialogueLine == 3:
                self.dialogueLine = 0
                self.CreateSave(0)
                self.NewFrame(None,frame,self.frames[ToBeContinued], None)
                self.after(2000, lambda: [self.destroy(), self.window.UpdateChapter(), self.window.deiconify()])
            elif self.decision == False:
                self.NextLine(frame, self.currentDialogue)

        elif frame == self.frames[FightResult]:

            self.frames[Footer].battle.pack_forget()
            self.frames[Header].backDrop.pack()
            self.frames[Footer].backDrop.pack()


            if self.fightResult == None:
                self.dialogueLine = 0
                self.NewFrame(None,frame,self.frames[ToBeContinued], None)
                self.after(2000, lambda: [self.destroy(), self.window.UpdateChapter(), self.window.deiconify()])

            if self.fightResult == True:
                self.dialogueLine = 0
                self.NextLine(frame, self.currentDialogue)
                self.fightResult = None
            elif self.fightResult == False:
                self.dialogueLine = 1
                self.NextLine(frame, self.currentDialogue)
                self.fightResult = None


        try:
            if self.currentFrame == self.frames[PhysicalFight]:
                self.inCombat = True
                self.FightSequence()
        except:
            self.inCombat = False

    def SMRTrue(self):
        self.SMRoute = True


    def PreviousDialogue(self, event, frame, dialogueList):
        if self.dialogueLine > 1:
            self.dialogueLine -= 1
            frame.Content(dialogueList[self.dialogueLine-1])
            

    def NewFrame(self, event, currentFrame, newFrame, newDialogue):
        currentFrame.pack_forget()
        self.currentFrame = newFrame
        self.currentDialogue = newDialogue
        newFrame.bind('<Button-1>', lambda event: self.Transition(event, self.currentFrame)) 
        newFrame.pack()
        self.decision = False

    def NextLine(self, frame, dialogueList):
        frame.Content(dialogueList[self.dialogueLine])
        self.dialogueLine += 1

    def FightSequence(self):

        if self.currentFrame.player[0].hp == 0:
            self.fightResult = False
            if self.SMRoute == True:
                self.CreateSave(1)
            else:
                self.CreateSave(2)
            self.NewFrame(None,self.currentFrame, self.frames[FightResult], self.dialogueFR)

        elif self.currentFrame.enemies[0].hp == 0 and self.currentFrame.enemies[1].hp == 0:
            self.fightResult = True
            if self.SMRoute == True:
                self.CreateSave(3)
            else:
                self.CreateSave(4)
            self.NewFrame(None,self.currentFrame, self.frames[FightResult], self.dialogueFR)


        if self.currentFrame.player[0].hp != self.currentFrame.player[0].previousHP:
            for i in range(0, len(self.currentFrame.enemies)):
                self.currentFrame.enemies[i].playerDodge = int(self.currentFrame.enemies[i].playerDodge *(self.currentFrame.player[0].hp/self.currentFrame.player[0].previousHP))
                self.currentFrame.enemies[i].playerDeflect = int(self.currentFrame.enemies[i].playerDeflect *(self.currentFrame.player[0].hp/self.currentFrame.player[0].previousHP))
                self.currentFrame.enemies[i].playerBlock = int(self.currentFrame.enemies[i].playerBlock *(self.currentFrame.player[0].hp/self.currentFrame.player[0].previousHP))
            self.currentFrame.player[0].resetHP()

        if self.currentFrame.playerInitiate == True and self.inFight == False:
            self.currentFrame.playerInitiate = False
            self.inFight = True
            self.playerTurn = False
            self.SurpriseAttack()

        if self.playerTurn == True and self.inFight == False:
            self.frames[Footer].battle.config(bg = '#00114f')
            self.inFight = True
            self.playerTurn = False
            self.PlayerAttack()

        elif self.playerTurn == False and self.inFight == False:
            self.frames[Footer].battle.config(bg = '#400500')
            self.inFight = True
            self.playerTurn = True
            self.EnemyAttack(self.currentFrame.enemies)



    def SurpriseAttack(self):
        surpriseAttackFrame = Frame(self.currentFrame, bg = 'black', height = 720, width = 1080)
        surpriseAttackFrame.pack()
        text = Label(surpriseAttackFrame, text = 'The enemy is not prepared, who do you want to attack?', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
        text.pack(side = 'top', pady = 50)
        for i in range(0, len(self.currentFrame.enemies)):
            if self.currentFrame.enemies[i].hp != 0 and i == 0:
                attackButton = ButtonFrame(surpriseAttackFrame, 300,100,'Attack ' + self.currentFrame.enemies[i].name, 24)
                attackButton.pack_propagate(False)
                attackButton.Button.bind('<Button-1>', lambda event: [self.currentFrame.enemies[0].loseOwnHP(), self.SurpriseAttackSuccess(),surpriseAttackFrame.destroy()])
                attackButton.pack(side = 'left', pady = 150, padx = 150)
                attackButton.Button.pack()
            elif self.currentFrame.enemies[i].hp != 0 and i == 1:
                attackButton = ButtonFrame(surpriseAttackFrame, 300,100,'Attack ' + self.currentFrame.enemies[i].name, 24)
                attackButton.pack_propagate(False)
                attackButton.Button.bind('<Button-1>', lambda event: [self.currentFrame.enemies[1].loseOwnHP(), self.SurpriseAttackSuccess(), surpriseAttackFrame.destroy()])
                attackButton.pack(side = 'right', pady = 150, padx = 150)
                attackButton.Button.pack()

    def SurpriseAttackSuccess(self):
        surpriseAttackSuccessFrame = Frame(self.currentFrame, bg = 'black')
        surpriseAttackSuccessFrame.pack()
        text = Label(surpriseAttackSuccessFrame, text = 'You got a successful hit on the enemy. The enemy is now weakened.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
        text.pack(side = 'top', pady = 50)
        self.after(1500, lambda: [self.CanFight(), self.Transition(None, self.currentFrame), surpriseAttackSuccessFrame.destroy()])



    def PlayerAttack(self):
        AttackFrame = Frame(self.currentFrame, bg = 'black', height = 720, width = 1080)
        AttackFrame.pack()
        text = Label(AttackFrame, text = 'You go for an attack. Who do you want to attack?', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
        text.pack(side = 'top', pady = 50)
        for i in range(0, len(self.currentFrame.enemies)):
            if self.currentFrame.enemies[i].hp != 0 and i == 0:
                attackButton = ButtonFrame(AttackFrame, 300, 100, 'Attack ' + self.currentFrame.enemies[i].name, 24)
                attackButton.pack_propagate(False)
                attackButton.Button.bind('<Button-1>', lambda event: [self.AttackEnemyHitChance(self.currentFrame.enemies[0]), AttackFrame.destroy()])
                attackButton.pack(side = 'left', pady = 150, padx = 150)
                attackButton.Button.pack()
            elif self.currentFrame.enemies[i].hp != 0 and i == 1:
                attackButton = ButtonFrame(AttackFrame, 300, 100,'Attack ' + self.currentFrame.enemies[i].name, 24)
                attackButton.pack_propagate(False)
                attackButton.Button.bind('<Button-1>', lambda event: [self.AttackEnemyHitChance(self.currentFrame.enemies[1]), AttackFrame.destroy()])
                attackButton.pack(side = 'right', pady = 150, padx = 150)
                attackButton.Button.pack()

    def AttackEnemyHitChance(self, enemy):
        enemyChoices = ['Dodge', 'Deflect', 'Block']
        enemyDefense = random.choice(enemyChoices)
        chance = random.randrange(0,101)
        enemyHit = Frame(self.currentFrame, bg = 'black')
        enemyHit.pack()

        Narration = ['The enemy tries to dodge the attack.','The enemy tries to deflect the attack.','The enemy tries to block the attack.','You missed the enemy.','Your attack got deflected.','Your attack is blocked by the enemy.','You got a successful hit on the enemy. The enemy is now weakened.','You got a successful hit on the enemy. The enemy is now knocked out.']

        if enemyDefense == 'Dodge':
            text = Label(enemyHit, text = Narration[0], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
            text.pack(side = 'top', pady = 50)
            if chance > enemy.dodge:
                enemy.loseOwnHP()
                if enemy.hp != 0:
                    text = Label(enemyHit, text = Narration[6], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
                else:
                    text = Label(enemyHit, text = Narration[7], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
            else:
                text = Label(enemyHit, text = Narration[3], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                self.after(1000,lambda: text.pack(side = 'top', pady = 50))

        elif enemyDefense == 'Deflect':
            text = Label(enemyHit, text = Narration[1], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
            text.pack(side = 'top', pady = 50)
            if chance > enemy.deflect:
                enemy.loseOwnHP()
                if enemy.hp != 0:
                    text = Label(enemyHit, text = Narration[6], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
                else:
                    text = Label(enemyHit, text = Narration[7], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
            else:
                text = Label(enemyHit, text = Narration[4], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                self.after(1000,lambda: text.pack(side = 'top', pady = 50))

        elif enemyDefense == 'Block':
            text = Label(enemyHit, text = Narration[2], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
            text.pack(side = 'top', pady = 50)
            if chance > enemy.block:
                enemy.loseOwnHP()
                if enemy.hp != 0:
                    text = Label(enemyHit, text = Narration[6], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
                else:
                    text = Label(enemyHit, text = Narration[7], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
            else:
                text = Label(enemyHit, text = Narration[5], font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                self.after(1000,lambda: text.pack(side = 'top', pady = 50))

        self.after(2500,lambda: [enemyHit.destroy(), self.CanFight(), self.Transition(None, self.currentFrame)])


    def EnemyAttack(self, enemies):
        EnemyAttackFrame = Frame(self.currentFrame, bg = 'black', height = 720, width = 1080)
        EnemyAttackFrame.pack_propagate(False)
        EnemyAttackFrame.pack()
        self.ButtonPressedFalse()
        text = Label(EnemyAttackFrame, text = 'The enemy attacks you. What do you do?', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
        text.pack(side = 'top', pady = 50)

        enemyNumber = random.randrange(0,len(enemies))
        while enemies[enemyNumber].hp == 0:
            enemyNumber = random.randrange(0,len(enemies))

        ButtonOrder = random.randrange(0,6)

        DodgeButton = ButtonFrame(EnemyAttackFrame, 150, 75, 'Dodge', 24)
        DodgeButton.pack_propagate(False)
        DodgeButton.Button.bind('<Button-1>', lambda event: [self.AttackPlayerHitChance('Dodge',enemyNumber), self.ButtonPressedTrue(), EnemyAttackFrame.destroy()])
        DeflectButton = ButtonFrame(EnemyAttackFrame, 150,75,'Deflect',24)
        DeflectButton.pack_propagate(False)
        DeflectButton.Button.bind('<Button-1>', lambda event: [self.AttackPlayerHitChance('Deflect',enemyNumber), self.ButtonPressedTrue(), EnemyAttackFrame.destroy()])
        BlockButton = ButtonFrame(EnemyAttackFrame, 150, 75,'Block', 24)
        BlockButton.pack_propagate(False)
        BlockButton.Button.bind('<Button-1>', lambda event: [self.AttackPlayerHitChance('Block',enemyNumber), self.ButtonPressedTrue(), EnemyAttackFrame.destroy()])

        if ButtonOrder == 0:
            DodgeButton.pack(side = 'left', pady = 50, padx = 150, anchor = N)
            DeflectButton.pack(side = 'right', pady = 50, padx = 150, anchor = N)
            BlockButton.pack(side = 'bottom', pady = 75, padx = 0)
            DodgeButton.Button.pack()
            DeflectButton.Button.pack()
            BlockButton.Button.pack()
        elif ButtonOrder == 1:
            DodgeButton.pack(side = 'left', pady = 50, padx = 150, anchor = N)
            BlockButton.pack(side = 'right', pady = 50, padx = 150, anchor = N)
            DeflectButton.pack(side = 'bottom', pady = 75, padx = 0)
            DodgeButton.Button.pack()
            DeflectButton.Button.pack()
            BlockButton.Button.pack()
        elif ButtonOrder == 2:
            DeflectButton.pack(side = 'left', pady = 50, padx = 150, anchor = N)
            DodgeButton.pack(side = 'right', pady = 50, padx = 150, anchor = N)
            BlockButton.pack(side = 'bottom', pady = 75, padx = 0)
            DodgeButton.Button.pack()
            DeflectButton.Button.pack()
            BlockButton.Button.pack()
        elif ButtonOrder == 3:
            DeflectButton.pack(side = 'left', pady = 50, padx = 150, anchor = N)
            BlockButton.pack(side = 'right', pady = 50, padx = 150, anchor = N)
            DodgeButton.pack(side = 'bottom', pady = 75, padx = 0)
            DodgeButton.Button.pack()
            DeflectButton.Button.pack()
            BlockButton.Button.pack()
        elif ButtonOrder == 4:
            BlockButton.pack(side = 'left', pady = 50, padx = 150, anchor = N)
            DodgeButton.pack(side = 'right', pady = 50, padx = 150, anchor = N)
            DeflectButton.pack(side = 'bottom', pady = 75, padx = 0)
            DodgeButton.Button.pack()
            DeflectButton.Button.pack()
            BlockButton.Button.pack()
        elif ButtonOrder == 5:
            BlockButton.pack(side = 'left', pady = 50, padx = 150, anchor = N)
            DeflectButton.pack(side = 'right', pady = 50, padx = 150, anchor = N)
            DodgeButton.pack(side = 'bottom', pady = 75, padx = 0)
            DodgeButton.Button.pack()
            DeflectButton.Button.pack()
            BlockButton.Button.pack()

        Buttons1 = [BlockButton,DeflectButton,BlockButton,DodgeButton,DeflectButton,DodgeButton]
        Buttons2 = [DodgeButton,BlockButton,DeflectButton,BlockButton,DodgeButton,DeflectButton]
        Buttons3 = [DeflectButton,DodgeButton,DodgeButton,DeflectButton,BlockButton,BlockButton]

        self.after(1500, lambda: Buttons1[ButtonOrder].destroy() if self.buttonPressed == False else None)
        self.after(2500, lambda: Buttons2[ButtonOrder].destroy() if self.buttonPressed == False else None)
        self.after(3500, lambda: Buttons3[ButtonOrder].destroy() if self.buttonPressed == False else None)
        if self.currentFrame.player[0].hp > 1:
            text = Label(EnemyAttackFrame, text = 'You done nothing and got hit. You are weakened.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
        else:
            text = Label(EnemyAttackFrame, text = 'You done nothing and got hit. You are knocked out.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
        self.after(3500, lambda: text.pack(side = 'top', pady = 0) if self.buttonPressed == False else None)
        self.after(5000, lambda: [self.currentFrame.player[0].loseOwnHP(), self.ButtonPressedTrue(), self.CanFight(), self.Transition(None, self.currentFrame), EnemyAttackFrame.destroy()] if self.buttonPressed == False else None)


    def AttackPlayerHitChance(self, playerChoice, enemy):
        playerDefense = playerChoice
        chance = random.randrange(0,101)
        playerHit = Frame(self.currentFrame, bg = 'black')
        playerHit.pack()

        if playerDefense == 'Dodge':
            if chance > (self.currentFrame.enemies[enemy].playerDodge+int((100-self.currentFrame.enemies[enemy].playerDodge)*(self.currentFrame.enemies[enemy].power))):
                self.currentFrame.player[0].loseOwnHP()
                if self.currentFrame.player[0].hp != 0:
                    text = Label(playerHit, text = 'You failed to dodge the attack. You are weakened.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
                else:
                    text = Label(playerHit, text = 'You failed to dodge the attack. You are knocked out.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
            else:
                text = Label(playerHit, text = 'You successfully dodge the attack.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                self.after(1000,lambda: text.pack(side = 'top', pady = 50))

        elif playerDefense == 'Deflect':
            if chance > (self.currentFrame.enemies[enemy].playerDeflect+int((100-self.currentFrame.enemies[enemy].playerDeflect)*(self.currentFrame.enemies[enemy].power))):
                self.currentFrame.player[0].loseOwnHP()
                if self.currentFrame.player[0].hp != 0:
                    text = Label(playerHit, text = 'You failed to deflect the attack. You are weakened.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
                else:
                    text = Label(playerHit, text = 'You failed to deflect the attack. You are knocked out.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
            else:
                text = Label(playerHit, text = 'You successfully deflect the attack.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                self.after(1000,lambda: text.pack(side = 'top', pady = 50))

        elif playerDefense == 'Block':
            if chance > (self.currentFrame.enemies[enemy].playerBlock+int((100-self.currentFrame.enemies[enemy].playerBlock)*(self.currentFrame.enemies[enemy].power))):
                self.currentFrame.player[0].loseOwnHP()
                if self.currentFrame.player[0].hp != 0:
                    text = Label(playerHit, text = 'You failed to block the attack. You are weakened.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
                else:
                    text = Label(playerHit, text = 'You failed to block the attack. You are knocked out.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                    self.after(1000,lambda: text.pack(side = 'top', pady = 50))
            else:
                text = Label(playerHit, text = 'You successfully block the attack.', font = ('MS Sans Serif', 24), bg = 'black', fg = 'white')
                self.after(1000,lambda: text.pack(side = 'top', pady = 50))
        self.after(2500,lambda: [playerHit.destroy(), self.CanFight(), self.Transition(None, self.currentFrame)])

    def CreateSave(self, path):
        f = open('Chapter 1 Save.txt', 'w')
        f.write(str(path))
        f.close()
        f = open('Chapters Available.txt','w')
        f.write('2')
        f.close()


    def CanFight(self):
        self.inFight = False
    def ButtonPressedTrue(self):
        self.buttonPressed = True
    def ButtonPressedFalse(self):
        self.buttonPressed = False


class Header(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class Footer(Frame):

    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class ChapterTitle(Frame):

    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')
        self.title = Label(self, text = 'Chapter 1 - The Dark Room', bg = 'black', fg = 'white', font = ('MS Sans Serif', 32))
        self.title.pack(pady = 150)

class ChapterExposition(Frame):

    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

    def Content(self, text):

        if '"' not in text:
            if '(' in text and ')' in text:
                try:
                    self.label.destroy()
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = '#c0faf0',)
                    self.label.pack(pady = 50)
                except:
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = '#c0faf0',)
                    self.label.pack(pady = 50)
            else:
                try:
                    self.label.destroy()
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = 'white',)
                    self.label.pack(pady = 50)
                except:
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = 'white',)
                    self.label.pack(pady = 50)
        if '"' in text:
            if 'You: ' in text:
                try:
                    self.label.destroy()
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = '#32a9db',)
                    self.label.pack(pady = 50)
                except:
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = '#32a9db',)
                    self.label.pack(pady = 50)

            if 'You: ' not in text and ': ' in text:
                try:
                    self.label.destroy()
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = '#edd577',)
                    self.label.pack(pady = 50)
                except:
                    self.label = Label(self, text = text, font = ('MS Sans Serif', 16), bg = 'black', fg = '#edd577',)
                    self.label.pack(pady = 50)

class GetAttention(ChapterExposition):

    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class StayMotionless(ChapterExposition):

    def __init__(self, parent):
        Frame.__init__(self,parent, bg = 'black')

class MeetPerson(ChapterExposition):

    def __init__(self, parent):
        Frame.__init__(self,parent, bg = 'black')

class PhysicalFight(Frame):
    def __init__(self, parent, playerInitiate, player, enemies):
        Frame.__init__(self,parent, bg = 'black')
        self.playerInitiate = playerInitiate
        self.player = player
        self.enemies = enemies

class FightResult(ChapterExposition):
    def __init__(self, parent):
        Frame.__init__(self,parent, bg = 'black')

class ToBeContinued(Frame):
    def __init__(self, parent):
        Frame.__init__(self,parent, bg = 'black')
        self.title = Label(self, text = 'To Be Continued...', bg = 'black', fg = 'white', font = ('MS Sans Serif', 32))# creates a label which holds chapter title
        self.title.pack(pady = 200)

class Enemy():
    def __init__(self, name, hp, dodge, deflect, block, power, playerDodge, playerDeflect, playerBlock):
        self.name = name
        self.hp = hp
        self.dodge = dodge
        self.deflect = deflect
        self.block = block
        self.power = power
        self.playerDodge = playerDodge
        self.playerDeflect = playerDeflect
        self.playerBlock = playerBlock

    def loseOwnHP(self):
        if self.hp > 0:
            self.hp -= 1
        if self.hp == 1:
            self.dodge = 5
            self.deflect = 40
            self.block = 50
            self.power = 0.5



class Player():
    def __init__(self, hp):
        self.hp = hp
        self.previousHP = hp

    def loseOwnHP(self):
        if self.hp > 0:
            self.previousHP = self.hp
            self.hp -= 1

    def resetHP(self):
        self.previousHP = self.hp
