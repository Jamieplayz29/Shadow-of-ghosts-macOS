
from Button import *
from ImportDialogue import *
from tkinter import *
import random

class Chapter2(Toplevel):

    def __init__(self, window):
        Toplevel.__init__(self, window)

        self.window = window
        self.title('???')
        self.geometry('1280x720')
        self.resizable(width = False, height = False)
        self.bind('<Return>', lambda event: self.Transition(self.currentFrame))
        
        self.container = Frame(self, width = 1280, height = 720, bg = 'black')
        self.container.pack_propagate(False)
        self.container.pack()
        self.container.bind('<Button-1>', lambda event: self.Transition(self.currentFrame))

        self.frames = {}
        self.currentFrame = None

        frameH = Header(self.container)
        self.frames[Header] = frameH
        frameF = Footer(self.container)
        self.frames[Footer] = frameF
        frameCT = ChapterTitle(self.container)
        self.frames[ChapterTitle] = frameCT


        self.ChapterStartUp()


    def ChapterStartUp(self):
        self.frames[Header].pack(side = 'top')
        self.frames[Footer].pack(side = 'bottom')

        self.frames[Header].backDropImage = PhotoImage(file = 'VinBack1Top.png')
        self.frames[Header].backDrop = Label(self.frames[Header], image = self.frames[Header].backDropImage)
        self.frames[Header].backDrop.pack(side = 'top')
        self.frames[Footer].backDropImage = PhotoImage(file = 'VinBack1Bottom.png')
        self.frames[Footer].backDrop = Label(self.frames[Footer], image = self.frames[Footer].backDropImage)
        self.frames[Footer].backDrop.pack(side = 'bottom')

        self.frames[ChapterTitle].pack(side = 'top')
        self.frames[ChapterTitle].bind('<Button-1>', lambda event: self.Transition(self.currentFrame))
        self.frames[ChapterTitle].title.bind('<Button-1>', lambda event: self.Transition(self.currentFrame))
        self.currentFrame = self.frames[ChapterTitle]

    def Transition(self, frame):
        if frame == self.frames[ChapterTitle]:
            self.window.UpdateChapter()
            self.window.deiconify()
            self.destroy()





class Header(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class Footer(Frame):

    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')
        
class ChapterTitle(Frame):

    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')
        self.title = Label(self, text = 'Coming Soon...', bg = 'black', fg = 'white', font = ('MS Sans Serif', 32))
        self.title.pack(pady = 150)
