from tkinter import *
from Chapter1 import *
from Chapter2 import *
from Button import *
from ImportDialogue import *

class MenuScreen(Tk):

    def __init__(self):
        Tk.__init__(self)

        self.title('Shadows of Ghosts')
        self.geometry('1280x720')
        self.resizable(width = False, height = False)

        self.container = Frame(self, width = 1280, height = 720, bg = 'black')
        self.container.pack_propagate(False)
        self.container.pack()
        self.frames = {}
        self.chosenChapter = None
        self.availableChapters = 0
        self.helpInfo = []
        self.helpFrame = 0

        try:
            f = open('Chapters Available.txt','r')
        except:
            f = open('Chapters Available.txt','w')
            f.write('1')
            f.close()

        frameH = Header(self.container)
        self.frames[Header] = frameH
        frameF = Footer(self.container)
        self.frames[Footer] = frameF
        frameTS = TitleScreen(self.container)
        self.frames[TitleScreen] = frameTS
        frameLS = LogoScreen(self.container)
        self.frames[LogoScreen] = frameLS
        frameSS = StartScreen(self.container)
        self.frames[StartScreen] = frameSS
        frameCS = ChapterSelection(self.container)
        self.frames[ChapterSelection] = frameCS
        frameHS = HelpScreen(self.container)
        self.frames[HelpScreen] = frameHS

        self.ShowTitle()

    def ShowTitle(self):
        self.frames[TitleScreen].pack()
        self.after(2000, lambda: [self.frames[TitleScreen].pack_forget(), self.frames[LogoScreen].pack()])
        self.after(4000, lambda: [self.frames[LogoScreen].pack_forget(), self.GameStartUp()])

    def GameStartUp(self):
        self.frames[Header].pack(side = 'top')
        self.frames[Footer].pack(side = 'bottom')
        self.frames[StartScreen].pack(side = 'top')

        self.frames[Header].backDropImage = PhotoImage(file = 'VinBack1Top.png')
        self.frames[Header].backDrop = Label(self.frames[Header], image = self.frames[Header].backDropImage)
        self.frames[Header].backDrop.pack(side = 'top')
        self.frames[Footer].backDropImage = PhotoImage(file = 'VinBack1Bottom.png')
        self.frames[Footer].backDrop = Label(self.frames[Footer], image = self.frames[Footer].backDropImage)
        self.frames[Footer].backDrop.pack(side = 'bottom')

        self.frames[StartScreen].FrameP = ButtonFrame(self.frames[StartScreen],None,None, 'Play', 32)
        self.frames[StartScreen].FrameH = ButtonFrame(self.frames[StartScreen],None,None, 'Help', 32)
        self.frames[StartScreen].FrameQ = ButtonFrame(self.frames[StartScreen],None,None, 'Quit', 32)
        self.frames[StartScreen].FrameP.pack(side = 'top')
        self.frames[StartScreen].FrameH.pack(side = 'top')
        self.frames[StartScreen].FrameQ.pack(side = 'top')

        self.frames[StartScreen].FrameP.Button.bind('<Button-1>', self.Selection)
        self.frames[StartScreen].FrameP.Button.pack(pady = 50)

        self.frames[StartScreen].FrameH.Button.bind('<Button-1>', self.Help)
        self.frames[StartScreen].FrameH.Button.pack(pady = 50)

        self.frames[StartScreen].FrameQ.Button.bind('<Button-1>', self.Exit)
        self.frames[StartScreen].FrameQ.Button.pack(pady = 50)

        LoadDialogue('Help.txt', self.helpInfo)

        self.ChapterSectionLayout()

        self.UpdateChapter()

        self.HelpLayout()

    def UpdateChapter(self):

        self.availableChapters = int(open('Chapters Available.txt').readline())

        if self.availableChapters == 1:
            self.frames[ChapterSelection].FrameBT.Chapter1.Button.pack(padx = 60, pady = 30)
        elif self.availableChapters == 2:
            self.frames[ChapterSelection].FrameBT.Chapter1.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter2.Button.pack(padx = 60, pady = 30)
        elif self.availableChapters == 3:
            self.frames[ChapterSelection].FrameBT.Chapter1.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter2.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter3.Button.pack(padx = 60, pady = 30)
        elif self.availableChapters == 4:
            self.frames[ChapterSelection].FrameBT.Chapter1.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter2.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter3.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBB.Chapter4.Button.pack(padx = 60, pady = 30)
        elif self.availableChapters == 5:
            self.frames[ChapterSelection].FrameBT.Chapter1.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter2.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter3.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBB.Chapter4.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBB.Chapter5.Button.pack(padx = 60, pady = 30)
        elif self.availableChapters == 6:
            self.frames[ChapterSelection].FrameBT.Chapter1.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter2.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBT.Chapter3.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBB.Chapter4.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBB.Chapter5.Button.pack(padx = 60, pady = 30)
            self.frames[ChapterSelection].FrameBB.Chapter6.Button.pack(padx = 60, pady = 30)

    def ChapterSectionLayout(self):
        self.frames[ChapterSelection].FrameT = Frame(self.frames[ChapterSelection], bg = 'black')
        self.frames[ChapterSelection].FrameT.pack(side = 'top')
        self.frames[ChapterSelection].FrameT.Title = Label(self.frames[ChapterSelection].FrameT, text = 'Chapter Selection', bg = 'black', fg = 'white', font = ('MS Sans Serif', 48))
        self.frames[ChapterSelection].FrameT.Title.pack(pady = 30)

        self.frames[ChapterSelection].FrameBT = Frame(self.frames[ChapterSelection], bg = 'black')
        self.frames[ChapterSelection].FrameBT.pack(side = 'top')
        self.frames[ChapterSelection].FrameBB = Frame(self.frames[ChapterSelection], bg = 'black')
        self.frames[ChapterSelection].FrameBB.pack(side = 'top')

        self.frames[ChapterSelection].FrameRB = ButtonFrame(self.frames[ChapterSelection],None,None, 'Back', 32)
        self.frames[ChapterSelection].FrameRB.pack(side = 'bottom')
        self.frames[ChapterSelection].FrameRB.Button.bind('<Button-1>',lambda event: self.Return(event, 0))
        self.frames[ChapterSelection].FrameRB.Button.pack(pady = 50)

        self.frames[ChapterSelection].FrameBT.Chapter1 = ButtonFrame(self.frames[ChapterSelection].FrameBT, 300, 100, 'Chapter 1', 32)
        self.frames[ChapterSelection].FrameBT.Chapter2 = ButtonFrame(self.frames[ChapterSelection].FrameBT, 300, 100, 'Chapter 2', 32)
        self.frames[ChapterSelection].FrameBT.Chapter3 = ButtonFrame(self.frames[ChapterSelection].FrameBT, 300, 100, 'Chapter 3', 32)
        self.frames[ChapterSelection].FrameBB.Chapter4 = ButtonFrame(self.frames[ChapterSelection].FrameBB, 300, 100, 'Chapter 4', 32)
        self.frames[ChapterSelection].FrameBB.Chapter5 = ButtonFrame(self.frames[ChapterSelection].FrameBB, 300, 100, 'Chapter 5', 32)
        self.frames[ChapterSelection].FrameBB.Chapter6 = ButtonFrame(self.frames[ChapterSelection].FrameBB, 300, 100, 'Chapter 6', 32)
        self.frames[ChapterSelection].FrameBT.Chapter1.pack_propagate(False)
        self.frames[ChapterSelection].FrameBT.Chapter2.pack_propagate(False)
        self.frames[ChapterSelection].FrameBT.Chapter3.pack_propagate(False)
        self.frames[ChapterSelection].FrameBB.Chapter4.pack_propagate(False)
        self.frames[ChapterSelection].FrameBB.Chapter5.pack_propagate(False)
        self.frames[ChapterSelection].FrameBB.Chapter6.pack_propagate(False)
        self.frames[ChapterSelection].FrameBT.Chapter1.pack(side = 'left')
        self.frames[ChapterSelection].FrameBT.Chapter2.pack(side = 'left')
        self.frames[ChapterSelection].FrameBT.Chapter3.pack(side = 'left')
        self.frames[ChapterSelection].FrameBB.Chapter4.pack(side = 'left')
        self.frames[ChapterSelection].FrameBB.Chapter5.pack(side = 'left')
        self.frames[ChapterSelection].FrameBB.Chapter6.pack(side = 'left')


        self.frames[ChapterSelection].FrameBT.Chapter1.Button.bind('<Button-1>', lambda event: self.SetChapter(event, 1))
        self.frames[ChapterSelection].FrameBT.Chapter2.Button.bind('<Button-1>', lambda event: self.SetChapter(event, 2))
        self.frames[ChapterSelection].FrameBT.Chapter3.Button.bind('<Button-1>', lambda event: self.SetChapter(event, 3))
        self.frames[ChapterSelection].FrameBB.Chapter4.Button.bind('<Button-1>', lambda event: self.SetChapter(event, 4))
        self.frames[ChapterSelection].FrameBB.Chapter5.Button.bind('<Button-1>', lambda event: self.SetChapter(event, 5))
        self.frames[ChapterSelection].FrameBB.Chapter6.Button.bind('<Button-1>', lambda event: self.SetChapter(event, 6))

    def HelpLayout(self):
        self.frames[HelpScreen].FrameMB = Frame(self.frames[HelpScreen], width = 1280, height = 400, bg= 'black')
        self.frames[HelpScreen].FrameMB.pack_propagate(False)
        self.frames[HelpScreen].FrameMB.pack(side = 'top')

        self.frames[HelpScreen].FrameMB.FrameLB = ButtonFrame(self.frames[HelpScreen].FrameMB, 50, 50, '<', 32)
        self.frames[HelpScreen].FrameMB.FrameLB.pack_propagate(False)
        self.frames[HelpScreen].FrameMB.FrameLB.pack(side = 'left', padx = 25)
        self.frames[HelpScreen].FrameMB.FrameLB.Button.bind('<Button-1>', self.PreviousHelpFrame)
        self.frames[HelpScreen].FrameMB.FrameLB.Button.pack()

        self.frames[HelpScreen].FrameMB.FrameRB = ButtonFrame(self.frames[HelpScreen].FrameMB, 50, 50, '>', 32)
        self.frames[HelpScreen].FrameMB.FrameRB.pack_propagate(False)
        self.frames[HelpScreen].FrameMB.FrameRB.pack(side = 'right', padx = 25)
        self.frames[HelpScreen].FrameMB.FrameRB.Button.bind('<Button-1>', self.NextHelpFrame)
        self.frames[HelpScreen].FrameMB.FrameRB.Button.pack()

        self.frames[HelpScreen].FrameMB.FrameC1 = Frame(self.frames[HelpScreen].FrameMB, width = 1080, height = 400, bg = 'black')
        self.frames[HelpScreen].FrameMB.FrameC2 = Frame(self.frames[HelpScreen].FrameMB, width = 1080, height = 400, bg = 'black')

        self.frames[HelpScreen].FrameMB.FrameC1.FrameD = Frame(self.frames[HelpScreen].FrameMB.FrameC1, width = 540, height = 400, bg = 'black')
        self.frames[HelpScreen].FrameMB.FrameC2.FrameB = Frame(self.frames[HelpScreen].FrameMB.FrameC2, width = 810, height = 400, bg = 'black')
        self.frames[HelpScreen].FrameMB.FrameC1.FrameD.pack_propagate(False)
        self.frames[HelpScreen].FrameMB.FrameC2.FrameB.pack_propagate(False)
        self.frames[HelpScreen].FrameMB.FrameC1.FrameD.pack(side = 'left')
        self.frames[HelpScreen].FrameMB.FrameC2.FrameB.pack(side = 'right')
        
        self.frames[HelpScreen].FrameRB = ButtonFrame(self.frames[HelpScreen], None, None, 'Back', 32)
        self.frames[HelpScreen].FrameRB.pack(side = 'bottom')
        self.frames[HelpScreen].FrameRB.Button.bind('<Button-1>',lambda event: self.Return(event, 1))
        self.frames[HelpScreen].FrameRB.Button.pack(pady = 10)

        self.frames[HelpScreen].FrameMB.FrameC1.FrameD.Title = Label(self.frames[HelpScreen].FrameMB.FrameC1.FrameD, text = 'Dialogue',bg = 'black', fg = 'white', font = ('MS Sans Serif', 24))
        self.frames[HelpScreen].FrameMB.FrameC1.FrameD.Title.pack(side = 'top', pady = 25)
        self.frames[HelpScreen].FrameMB.FrameC1.FrameD.Content = Label(self.frames[HelpScreen].FrameMB.FrameC1.FrameD, text = self.helpInfo[0],bg = 'black', fg = 'white', font = ('MS Sans Serif', 18))
        self.frames[HelpScreen].FrameMB.FrameC1.FrameD.Content.pack()

        self.frames[HelpScreen].FrameMB.FrameC2.FrameB.Title = Label(self.frames[HelpScreen].FrameMB.FrameC2.FrameB, text = 'Combat',bg = 'black', fg = 'white', font = ('MS Sans Serif', 24))
        self.frames[HelpScreen].FrameMB.FrameC2.FrameB.Title.pack(side = 'top', pady = 25)
        self.frames[HelpScreen].FrameMB.FrameC2.FrameB.Content = Label(self.frames[HelpScreen].FrameMB.FrameC2.FrameB, text = self.helpInfo[1],bg = 'black', fg = 'white', font = ('MS Sans Serif', 18))
        self.frames[HelpScreen].FrameMB.FrameC2.FrameB.Content.pack()



        self.UpdateHelpFrame()

    

    def Selection(self, event):
        self.frames[StartScreen].pack_forget()
        self.frames[ChapterSelection].pack()

    def SetChapter(self, event, chapter):
        self.chosenChapter = chapter
        if chapter == 1:
            ChapterWindow = Chapter1(self)
            self.withdraw()
            ChapterWindow.mainloop()
        elif chapter == 2:
            ChapterWindow = Chapter2(self)
            self.withdraw()
            ChapterWindow.mainloop()


    def Return(self, event, option):
        if option == 0:
            self.frames[ChapterSelection].pack_forget()
            self.frames[StartScreen].pack()

        if option == 1:
            self.frames[HelpScreen].pack_forget()
            self.frames[StartScreen].pack()

    def UpdateHelpFrame(self):
        if self.helpFrame == 0:
            self.frames[HelpScreen].FrameMB.FrameC2.pack_forget()
            self.frames[HelpScreen].FrameMB.FrameC1.pack(side = 'top')
        elif self.helpFrame == 1:
            self.frames[HelpScreen].FrameMB.FrameC1.pack_forget()
            self.frames[HelpScreen].FrameMB.FrameC2.pack(side = 'top')

    def PreviousHelpFrame(self, event):
        if self.helpFrame == 0:
            self.helpFrame = 1
            self.UpdateHelpFrame()
        else:
            self.helpFrame -= 1
            self.UpdateHelpFrame()

    def NextHelpFrame(self, event):
        if self.helpFrame == 1:
            self.helpFrame = 0
            self.UpdateHelpFrame()
        else:
            self.helpFrame += 1
            self.UpdateHelpFrame()

    def Help(self, event):
        self.frames[StartScreen].pack_forget()
        self.frames[HelpScreen].pack()


    def Exit(self, event):
        self.destroy()


class Header(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class Footer(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class TitleScreen(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')
        self.title = Label(self, text = 'Shadows of Ghosts', bg = 'black', fg = 'white', font = ('MS Sans Serif', 64))
        self.title.pack(pady = 250)

class LogoScreen(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')
        content = Frame(self, bg = 'black')
        content.pack(pady = 160)
        self.title = Label(content, text = 'by', bg = 'black', fg = 'white', font = ('MS Sans Serif', 32))
        self.title.pack()
        self.logoImage = PhotoImage(file = 'WdangcanC Logo Resized.png')
        self.logo = Label(content, image = self.logoImage, bg = 'black')
        self.logo.pack(pady = 30)

class StartScreen(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class ChapterSelection(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

class HelpScreen(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent, bg = 'black')

