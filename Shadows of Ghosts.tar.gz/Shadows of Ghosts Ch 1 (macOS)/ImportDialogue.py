import ast

def LoadDialogue(filePath, dialogueList):
        lineCount = len(open(filePath).readlines())
        dialogueFile = open(filePath, 'r')
        fileContent = dialogueFile.readlines()
        for l in range(0,lineCount):
            fileContent[l] = fileContent[l].replace('\\n','\n').replace("\\'","\'").rstrip()
            if '[' in fileContent[l] and ']' in fileContent[l]:
                fileContent[l] = ast.literal_eval(fileContent[l])
            dialogueList.append(fileContent[l])
