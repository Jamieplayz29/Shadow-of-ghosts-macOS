from setuptools import setup

APP = ['main.py']
DATA_FILES = ['VinBack1Bottom.png','VinBack1Top.png','VinBack2Cut.png','WdangcanC Logo Resized.png','WdangcanC Logo.png','Help.txt','DialogueCE.txt','DialogueFR.txt','DialogueGA.txt','DialogueMP.txt','DialogueSM.txt']
OPTIONS = {
 'iconfile':'Icon.ico',
 'argv_emulation': True,
 'packages': ['certifi'],
}

setup(
    app=APP,
    data_files=DATA_FILES,
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
)
